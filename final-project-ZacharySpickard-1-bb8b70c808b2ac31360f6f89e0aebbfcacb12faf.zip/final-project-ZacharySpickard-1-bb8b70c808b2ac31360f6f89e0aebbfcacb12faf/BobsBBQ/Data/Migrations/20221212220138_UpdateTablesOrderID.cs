﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BobsBBQ.Data.Migrations
{
    public partial class UpdateTablesOrderID : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "OrderNumber",
                table: "Side",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "OrderNumber",
                table: "Entree",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<decimal>(
                name: "OrderNumber",
                table: "Dessert",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OrderNumber",
                table: "Side");

            migrationBuilder.DropColumn(
                name: "OrderNumber",
                table: "Entree");

            migrationBuilder.DropColumn(
                name: "OrderNumber",
                table: "Dessert");
        }
    }
}
