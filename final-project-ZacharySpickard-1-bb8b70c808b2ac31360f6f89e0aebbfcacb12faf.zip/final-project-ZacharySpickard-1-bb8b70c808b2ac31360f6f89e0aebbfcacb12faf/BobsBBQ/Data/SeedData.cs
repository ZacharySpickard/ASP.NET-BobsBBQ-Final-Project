﻿using Microsoft.EntityFrameworkCore;
using BobsBBQ.Models;
using System; 

namespace BobsBBQ.Data
{
        public static class DbInitializer
        {
            public static void Initialize(ApplicationDbContext context)
            {
                    // Look for any movies.
                    if (context.Entree.Any())
                    {
                        return; // DB has been seeded
                    }
                    context.Entree.AddRange(
                    new Entree
                    {
                        OrderNumber = 1,
                        Name = "Chicken Wings Grill",
                        Description = "Chicken Grilled with Special Sauce",
                        Price = 19.99M,
                        NumSides = 1,
                        Calories = 234
                    },
                    new Entree
                    {
                        OrderNumber= 2,
                        Name = "Chicken Kebab",
                        Description = "Chicken Kebab with Mayonnaise",
                        Price = 18.00M,
                        NumSides = 2,
                        Calories = 260
                    },
                    new Entree
                    {
                        OrderNumber = 3,    
                        Name = "Smokey BBQ",
                        Description = "Smokey BBQ with Special Sauce",
                        Price = 18.00M,
                        NumSides = 2,
                        Calories = 280
                    },
                    new Entree
                    {
                        OrderNumber = 4, 
                        Name = "Chicken BBQ",
                        Description = "Chicken BBQ with Mayonnaise",
                        Price = 20.00M,
                        NumSides = 2,
                        Calories = 320
                    },
                     new Entree
                     {
                         OrderNumber = 5, 
                         Name = "Smokey Crab",
                         Description = "Chicken Crab with Special Sauce",
                         Price = 20.00M,
                         NumSides = 1,
                         Calories = 380
                     },
                     new Entree
                     {
                         OrderNumber = 6, 
                         Name = "Boneless Fish",
                         Description = "Boneless Fish with Spicy Sauce",
                         Price = 18.00M,
                         NumSides = 2,
                         Calories = 349
                     }
                    );
                    context.Side.AddRange(
                    new Side
                    {
                        OrderNumber = 7,
                        Name = "Sweet Potato Fries",
                        Description = "Basket of tasty strips of sweet potatoes deep fried.",
                        Price = 4.75M,
                        Calories = 390
                    },
                    new Side
                    {
                        OrderNumber = 8, 
                        Name = "Smoked Nachos Grande",
                        Description = "Torilla chips heaped with pulled pork, cheddar cheese, lettuce, tomatoes, salsa, and sour cream.",
                        Price = 7.50M,
                        Calories = 480
                    },
                    new Side
                    {
                        OrderNumber = 9,
                        Name = "Buffalo Shrimp Skewers ",
                        Description = "Two skewers of grilled BBQ shrimp. ",
                        Price = 7.25M,
                        Calories = 420
                    },
                    new Side
                    {
                        OrderNumber = 10,
                        Name = "Chicken Fingers ",
                        Description = "Strips of fresh chicken breast, deep fried to a golden brown and served with honey mustard of BBQ sauce.",
                        Price = 6.50M,
                        Calories = 360
                    },
                    new Side
                    {
                        OrderNumber = 11,
                        Name = "Mini Chicken Quesadillia ",
                        Description = "3 mini chicken quesadillias with sour cream and salsa.",
                        Price = 6.50M,
                        Calories = 520 
                    }
                     
                    );
                    context.Dessert.AddRange(
                     new Dessert
                     {
                         OrderNumber = 12, 
                         Name = "Apple Crumb Pie",
                         Description = "Lightly spiced sweet and tart apples topped with sweet crumbs with a hint of cinnamon.",
                         Price = 7.50M,
                         Calories = 650
                     },
                     new Dessert
                     {
                         OrderNumber = 13, 
                         Name = "Red Velvet Cake",
                         Description = "Our red velvet cake is a classic southern dish.", 
                         Price = 7.50M,
                         Calories = 690
                     },
                     new Dessert
                     {
                         OrderNumber = 14, 
                         Name = "Chocolate Cake",
                         Description = "Our fan-favorite chocolate cake that is topped with ice cream.",
                         Price = 7.50M,
                         Calories = 750
                     },
                     new Dessert
                     {
                         OrderNumber = 15, 
                         Name = "Brownie Sundae",
                         Description = "A sundae topped with a rich chocolate brownie.",
                         Price = 6.00M,
                         Calories = 620
                     }
                 );
                    context.Combos.AddRange(
                    new Combos
                    {
                        EntreeId =1 ,
                        SideId =7 ,
                        DessertId = 12 ,
                        Calories = 1274
                    },
                     new Combos
                     {
                         EntreeId = 2 ,
                         SideId = 8,
                         DessertId = 13,
                         Calories = 1390
                    },
                     new Combos
                     {
                         EntreeId = 3,
                         SideId = 9,
                         DessertId = 14,
                         Calories =1450
                    },
                     new Combos
                     {
                         EntreeId = 4,
                         SideId = 10,
                         DessertId = 15,
                         Calories = 1430
                    }
                 );
                     context.Sauce.AddRange(
                    new Sauce
                    {
                        Name = "The Rookie",
                        Price = 8.65M,
                        IsSoldSeperate = true,
                        IsActive = true,
                        SizeSold = 16,
                        Calories =  678
                    },
                     new Sauce
                     {
                         Name = "Sweet and Spicy BBQ",
                         Price = 9.00M,
                         IsSoldSeperate = true,
                         IsActive = true,
                         SizeSold = 16,
                         Calories = 689
                    },
                     new Sauce
                      {
                          Name = "Honey, I'm home!",
                          Price = 8.65M,
                          IsSoldSeperate = true,
                          IsActive = true,
                          SizeSold = 16,
                          Calories = 600
                    },
                      new Sauce
                      {
                          Name = "The Firefighter",
                          Price = 2.00M,
                          IsSoldSeperate = true,
                          IsActive = true,
                          SizeSold = 2,
                          Calories = 160
                    }
                 );

            context.SaveChanges();
                }
            }
        }
