﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Models;

namespace BobsBBQ.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<BobsBBQ.Models.Contact> Contact { get; set; }
        public DbSet<BobsBBQ.Models.Side> Side { get; set; }
        public DbSet<BobsBBQ.Models.Entree> Entree { get; set; }
        public DbSet<BobsBBQ.Models.Sauce> Sauce { get; set; }
        public DbSet<BobsBBQ.Models.Dessert> Dessert { get; set; }
        public DbSet<BobsBBQ.Models.Newsletter> Newsletter { get; set; }
        public DbSet<BobsBBQ.Models.Combos> Combos { get; set; }
       
        
        
    }
}