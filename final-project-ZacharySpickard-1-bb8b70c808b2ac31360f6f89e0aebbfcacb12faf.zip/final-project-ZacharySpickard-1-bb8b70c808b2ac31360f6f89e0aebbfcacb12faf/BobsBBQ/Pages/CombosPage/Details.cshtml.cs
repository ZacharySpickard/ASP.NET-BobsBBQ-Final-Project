﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;

namespace BobsBBQ.Pages.CombosPage
{
    public class DetailsModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public DetailsModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public Combos Combos { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Combos == null)
            {
                return NotFound();
            }

            var combos = await _context.Combos.FirstOrDefaultAsync(m => m.Id == id);
            if (combos == null)
            {
                return NotFound();
            }
            else 
            {
                Combos = combos;
            }
            return Page();
        }
    }
}
