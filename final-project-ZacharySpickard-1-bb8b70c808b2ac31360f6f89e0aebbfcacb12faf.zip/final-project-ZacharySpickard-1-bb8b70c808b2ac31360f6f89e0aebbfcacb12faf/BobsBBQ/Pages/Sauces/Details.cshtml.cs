﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;

namespace BobsBBQ.Pages.Sauces
{
    public class DetailsModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public DetailsModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public Sauce Sauce { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Sauce == null)
            {
                return NotFound();
            }

            var sauce = await _context.Sauce.FirstOrDefaultAsync(m => m.Id == id);
            if (sauce == null)
            {
                return NotFound();
            }
            else 
            {
                Sauce = sauce;
            }
            return Page();
        }
    }
}
