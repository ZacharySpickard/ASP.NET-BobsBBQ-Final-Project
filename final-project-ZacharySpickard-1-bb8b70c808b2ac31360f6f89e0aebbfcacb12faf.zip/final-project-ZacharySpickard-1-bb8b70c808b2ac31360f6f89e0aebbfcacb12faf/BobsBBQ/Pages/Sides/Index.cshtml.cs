﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;
using Microsoft.AspNetCore.Authorization;

namespace BobsBBQ.Pages.Sides
{
    [AllowAnonymous]
    public class IndexModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public IndexModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Side> Side { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Side != null)
            {
                Side = await _context.Side.ToListAsync();
            }
        }
    }
}
