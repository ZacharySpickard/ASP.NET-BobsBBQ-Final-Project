﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;

namespace BobsBBQ.Pages.Sides
{
    public class DetailsModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public DetailsModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public Side Side { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Side == null)
            {
                return NotFound();
            }

            var side = await _context.Side.FirstOrDefaultAsync(m => m.Id == id);
            if (side == null)
            {
                return NotFound();
            }
            else 
            {
                Side = side;
            }
            return Page();
        }
    }
}
