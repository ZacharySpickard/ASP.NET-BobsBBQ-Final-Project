﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;

namespace BobsBBQ.Pages.Sides
{
    public class DeleteModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public DeleteModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Side Side { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Side == null)
            {
                return NotFound();
            }

            var side = await _context.Side.FirstOrDefaultAsync(m => m.Id == id);

            if (side == null)
            {
                return NotFound();
            }
            else 
            {
                Side = side;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Side == null)
            {
                return NotFound();
            }
            var side = await _context.Side.FindAsync(id);

            if (side != null)
            {
                Side = side;
                _context.Side.Remove(Side);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
