using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization; 

namespace BobsBBQ.Pages
{
    [AllowAnonymous]
    public class MenuModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
