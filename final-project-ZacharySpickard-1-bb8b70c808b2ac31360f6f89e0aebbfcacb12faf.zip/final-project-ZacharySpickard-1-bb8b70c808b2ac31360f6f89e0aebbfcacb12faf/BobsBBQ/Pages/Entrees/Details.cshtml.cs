﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BobsBBQ.Data;
using BobsBBQ.Models;

namespace BobsBBQ.Pages.Entrees
{
    public class DetailsModel : PageModel
    {
        private readonly BobsBBQ.Data.ApplicationDbContext _context;

        public DetailsModel(BobsBBQ.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public Entree Entree { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Entree == null)
            {
                return NotFound();
            }

            var entree = await _context.Entree.FirstOrDefaultAsync(m => m.Id == id);
            if (entree == null)
            {
                return NotFound();
            }
            else 
            {
                Entree = entree;
            }
            return Page();
        }
    }
}
