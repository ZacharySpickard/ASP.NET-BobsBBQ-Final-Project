﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Entree
    {
        public int Id { get; set; }
        [Required]
        public decimal OrderNumber { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
        public int NumSides { get; set; }
        public decimal Calories { get; set; }

    }
}
