﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Sauce
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
        public bool IsSoldSeperate { get; set; }
        public bool IsActive { get; set; }
        public int SizeSold { get; set; }
        public decimal Calories { get; set; } 
    }
}
