﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Contact
    {
        public int Id { get; set; }
        [Required]
        [Display(Name = "First Name")]
        [StringLength(50)]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        [StringLength(50)]
        public string LastName { get; set; }

        [DataType(DataType.EmailAddress, ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }

        [Display(Name = "Phone Number")]
        [DataType(DataType.PhoneNumber, ErrorMessage = "Phone Number is not valid")]
        public string PhoneNumber { get; set; }
        
        [Range(18,100)]
        public int Age { get; set; }
        
        [Display(Name ="Reason for Contact")]
        [StringLength(200)]
        public string Description { get; set; }
    }
}
