﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Dessert
    {
        public int Id { get; set; }
        [Required]
        public decimal OrderNumber { get; set; }
        [Required]
        public string Name { get; set; }
        [StringLength(150)]
        public string Description { get; set; }
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        public decimal Calories { get; set; }
    }
}
