﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Combos
    {
        public int Id { get; set; }

        [ForeignKey("Entree")]
        [Display(Name = "Entree Id")]
        public int EntreeId { get; set; }

        [ForeignKey("Side")]
        [Display(Name = "Side Id")]
        public int SideId { get; set; }

        [ForeignKey("Dessert")]
        [Display(Name = "Dessert Id")]

        public int DessertId { get; set; }

        public decimal Calories { get; set; }
    }
}
