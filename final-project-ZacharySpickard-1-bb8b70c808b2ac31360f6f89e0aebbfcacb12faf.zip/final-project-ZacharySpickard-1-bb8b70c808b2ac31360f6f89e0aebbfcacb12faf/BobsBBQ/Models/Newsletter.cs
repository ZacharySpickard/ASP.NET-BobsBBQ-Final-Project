﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Newsletter
    {
        public int NewsletterId { get; set; }
        public string? OwnerID { get; set; } 

        public string Name { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        
        [Required]
        [Display(Name = "Subscribe?")]
        public bool IsSubscribed { get; set; }

        public SubscribeStatus SubscribeStatus { get; set;  }
     
    }
    public enum SubscribeStatus
    {
        Submitted,
        Approved,
        Rejected
    }
}
