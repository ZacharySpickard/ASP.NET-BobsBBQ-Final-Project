﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BobsBBQ.Models
{
    public class Side
    {
        public int Id { get; set; }
        public decimal OrderNumber { get; set; }
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }
        public decimal Calories { get; set; }
    }
}
