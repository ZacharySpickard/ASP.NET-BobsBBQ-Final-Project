﻿namespace Menu.Products
{
    public class Class1
    {

    }
}