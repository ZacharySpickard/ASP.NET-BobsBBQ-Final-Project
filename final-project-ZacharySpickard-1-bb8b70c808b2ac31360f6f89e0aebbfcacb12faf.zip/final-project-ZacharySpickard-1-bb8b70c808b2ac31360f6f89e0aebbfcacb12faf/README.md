For our final project, you will be tasked with working with Bob, a client who has come to you for help with his new website. Bob is following his dream of opening his own restaurant and needs your help building the website to support it.

In the following write up, you will learn about his Restaurant and some of the things he would like included on his website. He has left some parts up to your imagination, especially around layouts and colors.

You will have until December 12th at 11:59 to turn your completed project in.

As part of the effort, you will need to meet with Bob (aka Me) between November 28 and December 9 at 5pm. This will be for a 30 minute discussion to demo your menu page and contact me page, during this meeting the client will give any important feedback and to ensure that everything is meeting their expectation. This meeting is worth 50 points of you final, so you better schedule and show up prepared to show your code. 


The Final Project is worth 200 points
	150 Points - Meet all the functional and technical requirements
	  50 Points - 30 Minute "Client" Meeting

There will be no late labs accepted. 
